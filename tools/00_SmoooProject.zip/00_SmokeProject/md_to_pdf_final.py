#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
将 Markdown 文件转换为 PDF，使用 markdown->HTML解析并保留样式
支持中文。
"""

import os
import markdown
from bs4 import BeautifulSoup
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, ListFlowable, ListItem
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont


def setup_chinese_font():
    try:
        pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
        return True
    except Exception:
        return False


def element_to_flowable(el, styles, font_name, bold_font):
    tag = el.name.lower()
    text = ''.join(str(c) for c in el.contents)
    if tag in ('h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p'):
        style = styles['Normal']
        if tag == 'h1':
            style = styles['Heading1']
        elif tag == 'h2':
            style = styles['Heading2']
        elif tag == 'h3':
            style = styles['Heading3']
        # convert inner HTML preserved by BeautifulSoup
        return Paragraph(str(el), style)
    elif tag in ('ul', 'ol'):
        items = []
        for li in el.find_all('li', recursive=False):
            items.append(ListItem(Paragraph(str(li), styles['Normal'])))
        return ListFlowable(items, bulletType='bullet' if tag=='ul' else '1')
    elif tag == 'table':
        data = []
        for row in el.find_all('tr'):
            row_data = []
            for cell in row.find_all(['td', 'th']):
                row_data.append(Paragraph(str(cell), styles['Normal']))
            data.append(row_data)
        t = Table(data)
        t.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.grey),
            ('TEXTCOLOR',(0,0),(-1,0),colors.whitesmoke),
            ('ALIGN',(0,0),(-1,-1),'CENTER'),
            ('GRID',(0,0),(-1,-1),1,colors.black)
        ]))
        return t
    else:
        # fallback: paragraph
        return Paragraph(str(el), styles['Normal'])


def markdown_to_pdf(markdown_file, pdf_file):
    has_chinese = setup_chinese_font()
    font_name = 'STSong-Light' if has_chinese else 'Helvetica'
    bold_font = 'STSong-Light' if has_chinese else 'Helvetica-Bold'

    with open(markdown_file, 'r', encoding='utf-8') as f:
        md = f.read()

    html = markdown.markdown(md, extensions=['tables', 'fenced_code'])
    soup = BeautifulSoup(html, 'lxml')

    doc = SimpleDocTemplate(pdf_file, pagesize=A4)
    styles = getSampleStyleSheet()
    # override some styles to use chinese font
    for key in styles.byName:
        styles.byName[key].fontName = font_name
    # 修改现有Heading样式以使用中文加粗字体
    styles.byName['Heading1'].fontName = bold_font
    styles.byName['Heading1'].fontSize = 18
    styles.byName['Heading2'].fontName = bold_font
    styles.byName['Heading2'].fontSize = 16
    styles.byName['Heading3'].fontName = bold_font
    styles.byName['Heading3'].fontSize = 14

    story = []
    for child in soup.body.children if soup.body else soup.children:
        if getattr(child, 'name', None):
            flow = element_to_flowable(child, styles, font_name, bold_font)
            if flow:
                story.append(flow)
                story.append(Spacer(1, 12))

    doc.build(story)
    print(f"生成PDF {pdf_file}")
    if has_chinese:
        print("已启用中文字体")
    else:
        print("未启用中文字体，如有中文显示问题请安装字体")


if __name__ == '__main__':
    md = 'Optimize_performance.md'
    pdf = 'Optimize_performance.pdf'
    if os.path.exists(md):
        markdown_to_pdf(md, pdf)
    else:
        print(f"找不到 {md}")
